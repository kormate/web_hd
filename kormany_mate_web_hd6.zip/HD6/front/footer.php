<footer>
	<div class="author">by Kormány Máté</div>
	<div class="link">
	<a id="up" href="#pagetop">&#8657;</a>
	</div>
</footer>

</body>
</html>