

<div class="page">
	
 
<table border="1px solid black" class="center" style="margin-left: 255px;">
	
		<tr><th>Név</th><th>Hónap</th><th>Nap</th></tr>
		<?php
			foreach ($mind as $rekord)
				echo "<tr>
					<td>$rekord[nev1], $rekord[nev2]</td>
					<td>$rekord[ho]</td>
					<td>$rekord[nap]</td>
				</tr>";
		?>
	
	</table>
	
</div>