<?php
    if (isset($_GET["nev"]) && $_GET["nev"] != ""){
        $mind = getApi($myApi."?nev=".$_GET["nev"]);
        if (!$mind) $mind = [];
    }
    else if (isset($_GET["honap"]) && $_GET["honap"] != "" && (isset($_GET["nap"]) && $_GET["nap"] != "")){
        $mind = getApi($myApi."?nap=".$_GET["honap"] && $_GET["nap"]);
        if (!$mind) $mind = [];
    }

?>

<style>

</style>

<div class="page">

    <?php
        if (isset($mind)) {
            echo "<p class='center'>
            Név: \"$_GET[nev]\" Hónap: $_GET[honap] \" Nap: $_GET[nap]
            </p>";
            include_once("tablazat.php");
        }
        else{

    ?>
    <div style="text-align:center;">
    <form method="GET" action="">
        <input type="hidden" name="p" value="1">
        <label>Név:</label>
        <input type="text" name="nev" style="width:100px;">
        <div>
        <label>Hónap:</label>
        <input type="number" min="1" max="12" name="honap">
        </div>
        <div>
        <label>Nap:</label>
        <input type="number" min="1" max="31" name="nap">
        </div>
        <input type="submit" value="Keresés" >
    </form>
    </div>

<?php } ?>

</div>