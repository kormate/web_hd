<?php 
    $mind = getApi($myApi."?nevnapok=mind");
    if (!$mind) $mind = [];

?>

<div class="page">
    
    <?php include_once("tablazat.php"); ?>

    <hr>

</div>