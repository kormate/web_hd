<?php
$page="pages/nevnapok.php";
$cim="Névnapok";

if (isset($_GET['p'])){
	switch ($_GET['p']) {
		case '1': {
			$page = "pages/kereses.php";
			$cim = "Keresés";
			break;
		}
	}
}

?>