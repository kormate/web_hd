<?php 
    function connect(){
        $host = "localhost";
        $user = "root";
        $pw = "";
        $dbname = "nevnapok";
    

        $conn = new mysqli($host, $user, $pw, $dbname);
        $conn or exit();

        $conn -> query("SET NAMES 'utf8'");
        $conn -> query("SET CHARACTER SET 'utf8'");

        return $conn;
    }
?>