<?php
    function adatLeker($sql){
        $array = false;
        $kapcs = connect();
        $e = $kapcs -> query($sql);
        if ($e && $e -> num_rows>0){
            $n = 0;
            while ($sor = $e -> fetch_assoc()) {
                $array[$n] = $sor;
                $n++;
            }
        }
        $kapcs -> close();
        return $array;
    }

    function adatLekerErtek($sql){
        $value = false;
        $kapcs = connect();
        $e = $kapcs -> query($sql);
        if ($e && $e -> num_rows> 0){
            $sor = $e -> fetch_assoc();
            $value = $sor[0];
        }
        $kapcs -> close();
        return $value;
    }

    function LekerAll(){
        $sql = "SELECT * FROM nevnap";
        return adatLeker($sql);
    }

    function egynev($nevek){
        $sql = "SELECT * FROM nevnap WHERE nev1 or nev2 = $nevek";
        return adatLeker($sql);
    }

    function ho_nap($md){
        $sql = "SELECT * FROM nevnap WHERE ho and nap = $md";
        return adatLeker($sql);
    }

    /*function honapnap($mezo, $ertek){
        switch ($mezo){
            case "ho":{ $feltetel = "ho = $ertek"; break; }
            case "nap":{$feltetel = "nap = $ertek"; break;}
            default: {$feltetel = true; break;}
        }
        $sql = "SELECT * FROM nevnapok WHERE $feltetel";
        return adatLeker($sql);
    }*/


?>