<?php 
      include_once("db_connect.php");
      include_once("db_functions.php");

    if (isset($_GET["nevnapok"]) && $_GET["nevnapok"] == "mind") $adat = LekerAll();
    else if (isset($_GET["nev"]) && $_GET["nev"] != "") $adat = egynev($_GET["nev"]);
    else if (isset($_GET["md"]) && $_GET["md"] != "") $adat = ho_nap($_GET["md"]);
    if (isset($adat)){
      $kod = 200;
      if (!$adat){
        $kod = 204;
        $adat = array(
          "üzenet" => "nincs találat",
        );
      }
    }
    else{
      $kod = 404;
      $adat = array(
        "minta1" => "?nevnapok=mind",
        "minta2" => "?md=12-31",
        "minta3" => "?nevek=Szilveszter"
      );
    }

    http_response_code($kod);
    header("Content-Type: application/json; charset=utf-8");
    $json = json_encode($adat);

    print $json;

?>