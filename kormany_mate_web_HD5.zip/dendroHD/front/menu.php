<?php
$page="pages/kezdolap.php";
$cim="";

if (isset($_GET['p'])){
	switch ($_GET['p']) {
		case '1': {
			$page = "pages/kezdolap.php";
			$cim = "";
			break;
		}
		case '2': {
			$page = "pages/kereses.php";
			$cim = "";
			break;
		}
		case '3': {
			$page = "pages/fak.php";
			$cim = "";
			break;
		}

	}
}

?>