<?php

	include_once("menu.php");
	include_once("header.php");
	include_once("main.php");
	include_once("footer.php");

?>





