
<p class="center">
	Az adatbázisunkban összesen <?php echo count($mind) ?> fa található.
	</p>
	<table>
		<tr><th>Faj</th><th>Körméret</th><th>Település</th><th>Mérés</th></tr>
		<?php
			foreach ($mind as $rekord)
				echo "<tr>
					<td>$rekord[faj]</td>
					<td>$rekord[kormeret]</td>
					<td>$rekord[telepules]</td>
					<td>$rekord[meres]</td>
				</tr>";
		?>
	</table>
