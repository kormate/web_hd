<?php 
    $mind = getApi($myApi."?fak=mind");
    if (!$mind) $mind = [];
?>

<div class="page">

    <?php include("tablazat.php"); ?>


</div>