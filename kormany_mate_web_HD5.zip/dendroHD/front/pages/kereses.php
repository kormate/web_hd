
<?php 
    if (isset($_GET["faj"]) && $_GET["faj"] != "")
    {
        $mind = getApi($myApi."?fafaj=".$_GET["faj"]);
        if (!$mind) $mind = [];
    }

?>

<div class="page">

        <?php 
            if (isset($mind))
            {
                echo "<p class='center'>
                Fajta: \"$_GET[faj]\" 
            </p>";
            include_once("tablazat.php");
            }
            else {
        ?>


        <h1 class="center">Keresés</h1>


        <form method="GET" action="">
            <input type="hidden" name="p" value="2">
            <label style="margin-bottom: 20px; display:block;">Törzskörméret (cm)</label>
              <div class="minmaxmeret">
                <label>min:</label>
                <input type="number" name="meret" min="100" max="1000">
              </div>
              <div class="minmaxmeret" style="margin-right: 6px;">
                <label>max:</label>
                <input type="number"  name="meret" min="100" max="1000">
              </div>
              
                <input type="submit" style="margin-bottom: 30px; margin-left: 180px; width: 200px;" value="Méretre keresek">
              
                <div class="minmaxmeret">
            <label>Faj:</label>
            <input type="text" name="faj">
                </div>
    
            <input type="submit" style="margin-bottom: 30px; margin-left: 176px; width: 200px;" value="Fajra keresek">
        </form>
        
    <?php } ?>

</div>
