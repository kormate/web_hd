<div class="page">

<h1>Dendrománia</h1>
<div style="float: right; margin-left:20px;">
<p><img src="./front/img/konyv.jpg"/><br>Pósfai György könyve</p>
</div>
<p>Talán sokan nem ismerik az új keletű kifejezést, a dendromániát, amely a növényrendszertannak a fás növényekkel foglalkozó ága, ebből alkották meg tréfásan a grafománia mintájára a dendrománia szót. A szóösszetétel a görög dendron szóból ered, ami fát jelent. A dendrománia pedig egyfajta szenvedély, ami a fákra irányul. A szó 2005-ben vált ismertté, amikor megjelent Pósfai György könyve: Magyarország legnagyobb fái – dendrománia címmel.</p>

<p>Pósfai György precíz természettudósként kidolgozott egy módszert, amellyel a lehető legpontosabban lehet megmérni a fák átmérőjét. De az ő alaposságán kívül a modern technika vívmányai is új lendületet adtak a nagy fák felmérésének. A terepi emberek a fák helyét GPS-szel azonosítják, a digitális fényképezőgéppel készült fotókat pedig percek alatt fel lehet tölteni az internetre, a listák villámgyorsan aktualizálhatók. De azért egy dzsungelszerű ártéri erdő mélyén, csalánon átgázolva, szúnyogokat csapkodva rátalálni egy óriási fekete nyárra ma is igazi kihívás.</p>

<h1>Mi számít nagynak?</h1>

<p>A dendromániások élete célja: minél több 6 m körméretűnél nagyobb fát megismerni és meghódítani - azaz megmérni, lefilmezni, látogatni és érte folyamatosan rajongani. Ilyen fából - nem számítva a nehezen számbavehető nyárfákat és füzeket - valószínűleg nincsen több háromszáznál. Elsősorban a tölgyek, hársak, szelídgesztenyék, platánok, nyárfák, füzek érik el ezt a méretet. Az oldalon elérhető adatbázisban kisebb méretek szerepelnek - kocsányos tölgyeknél, szelídgesztenyéknél 500 centiméterig, egyéb (vörös, molyhos, kocsánytalan) tölgyeknél, hársaknál, kőriseknél, szileknél, bükköknél 400-ig. Az ennél kisebb méretet elérő egyéb fák adatai kisebb számban szerepelnek a listákban, és ezek is inkább a fajukban kapitálisnak számító példányok.</p>





</div>