<footer>
	<div>Forrás:<a target="_blank" href="http://dendromania.hu/">dendromania.hu</a></div>
	<br><br>
	<div class="author">by Kormány Máté</div>
	<div class="link">
	<a id="up" href="#pagetop">&#8657;</a>
	</div>
</footer>

</body>
</html>