<main>
<h1><?php echo $cim ?></h1>
<?php include_once($page); ?>
</main>