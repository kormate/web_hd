<?php 
    include_once("db_connect.php");
    include_once("db_funcs.php");


    if (isset($_GET["fafaj"]) && $_GET["fafaj"] != "")
        $adat = keres("faj",$_GET["fafaj"]);

    if (isset($adat))
    {
        $kod = 200;
        if (!$adat)
        {
            $kod = 204;
            $adat = array("üzenet" => "nincs találat");
        }
    }
    else{
        $kod = 404;
        $adat = array(
            "minta1" => "?fak=mind",
            "minta2" => "?fafaj=fekete bodza",
            "minta3" => "?fafaj=fekete"
        );
    }

    http_response_code($kod);
    header('Content-Type: application/json; charset=utf-8');
    $json=json_encode($adat);

    print $json;

?>