<?php

function osszesAdat($sql){
    $array = false;
    $kapcsolat = connect();
    $eredmeny = $kapcsolat -> query($sql);
    if ($eredmeny && $eredmeny -> num_rows > 0){
        $n = 0;
        while ($sor = $eredmeny -> fetch_assoc()){
            $array[$n] = $sor;
            $n++;
        }
    }
}

// egy érték
function adatlekeresErtek($sql){
    $value = false;
    $kapcsolat = connect();
    $eredmeny = $kapcsolat -> query($sql);
    if ($eredmeny && $eredmeny -> num_rows > 0){
        $sor = $eredmeny -> fetch_assoc();
        $value = $sor;
    }
    $kapcsolat -> close();
    return $value;
}

function egyfa($fafaj){
    $sql = "SELECT * FROM fak WHERE faj LIKE '%$fafaj%'";
    return osszesAdat($sql);
}

function keres($mezo, $ertek){
    switch ($mezo){
        case "faj": {
            $feltetel = "faj LIKE '%$ertek%'";
            break;
        }
        default: {
            $feltetel = true;
            break;
        }
    }
}

?>