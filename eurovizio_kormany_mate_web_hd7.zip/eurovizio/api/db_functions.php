<?php 
    function adatLekeres($sql){
        $array = false;
        $kapcsolat = connect();
        $e = $kapcsolat -> query($sql);
        if ($e && $e -> num_rows > 0){
            $n = 0;
            while ($sor = $e -> fetch_assoc()){
                $array[$n] = $sor;
                $n++;
            }
        }
        $kapcsolat -> close();
        return $array;
    }

    function adatErtek($sql){
        $value = false;
        $kapcsolat = connect();
        $e = $kapcsolat -> query($sql);
        if ($e && $e -> num_rows > 0){
            $sor = $e -> fetch_assoc();
            $value = $sor[0];
        }
        $kapcsolat -> close();
        return $value;
    }


    function LekerAll(){
        $sql = "SELECT * FROM dal";
        return adatLekeres($sql);
    }

    function LekerPont(){
        $sql = "SELECT ev, eloado, dal, edonto, epont, donto, dpont FROM dal";
        return adatLekeres($sql);
    }
    function LekerTabla($tablazat){
        $sql = "SELECT ev, orszag, eloado FROM dal";
        return adatLekeres($sql);
    }
?>