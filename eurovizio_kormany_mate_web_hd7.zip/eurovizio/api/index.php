<?php 
    include_once("db_connect.php");
    include_once("db_functions.php");

    if (isset($_GET["resztvevo"]) && $_GET["resztvevo"] == "mind") $adat = LekerAll();
    if (isset($adat)) {
        $kod = 200;
        if(!$adat){
            $kod = 204;
            $adat = array(
                "üzenet" => "nincs találat"
            );
        }
    }
    else {
        $kod = 404;
        $adat = array(
            "minta1" => "?resztvevo=mind",
            "minta2" => "?resztvevo=valogato",
            "minta3" => "?resztvevo=elodonto",
            "minta4" => "?resztvevo=donto",
            "minta5" => "?ev=2007"
        );
    }
    http_response_code($kod);
    header("Content-Type: application/json; charset=utf-8");
    $json = json_encode($adat);

    print $json;
?>