-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2024. Ápr 03. 12:41
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `vizsga`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `dal`
--

CREATE TABLE `dal` (
  `eloado` varchar(50) DEFAULT NULL,
  `nev` varchar(50) DEFAULT NULL,
  `info` text DEFAULT NULL,
  `ev` int(4) NOT NULL,
  `orszag` varchar(50) NOT NULL,
  `dal` varchar(50) DEFAULT NULL,
  `donto` int(11) DEFAULT NULL,
  `dpont` int(11) DEFAULT NULL,
  `edonto` int(11) DEFAULT NULL,
  `epont` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `dal`
--

INSERT INTO `dal` (`eloado`, `nev`, `info`, `ev`, `orszag`, `dal`, `donto`, `dpont`, `edonto`, `epont`) VALUES
('Szulák Andrea', NULL, 'Énekesnő, színésznő, műsorvezető. Sokáig külföldön vendég tánczenész volt, majd a Neoton Família kettészakadása utáni új Neoton együttes énekesnője. Gyakran lép fel musicalekben és zenés darabokban. 1991-ben Moszkvában megnyerte az OIRT-fesztivál nagydíját. 1992-ben Egerben győzött a táncdalfesztiválon. 1993-ban elsőként képviselte volna Magyarországot az Eurovíziós Dalfesztiválon, de nem jutott tovább a kelet-európai országok számára rendezett előválogatón. 1994-ben az év énekesnőjévé választották.2016 óta a Turay Ida Színház tagja.', 1993, 'Írország', 'Árva reggel', NULL, NULL, NULL, NULL),
('Friderika', 'Bayer Friderika', 'Énekesnő. Az Eurovíziós Dalfesztiválon elért sikerért a Magyar Rádió eMeRTon-díjban részesítette, a szakma és a közönség együttes szavazata alapján az Axel Springer Kiadó által létrehozott Aranyszarvas díjat kapta meg az év popénekese kategóriájában, 1994-ben. Ugyanebben az évben az Ifjúsági Magazin olvasói is az év popénekesnőjének választották. 1995. január 25-én a Magyar Televízió és a Rádió nyilvánossága előtt (immáron már másodízben) vehette át az eMeRTon-díjat mint az év felfedezettje. Ezután jött még a MAHASZ által létrehozott Arany Zsiráf díj, ugyanezért a címért.', 1994, 'Írország', 'Kinek mondjam el vétkeimet?', 4, 122, NULL, NULL),
('Szigeti Csaba', NULL, 'Zongorista, zeneszerző, énekes. Számos magyar előadóval dolgozott együtt az 1990-es évek elején. 1992-ben hazajött, majd abban az évben az egri táncdalfesztiválon a Hold ma éjjel című dallal elnyerte a különdíjat. 1994-ben a Magyar Televízió által megrendezett táncdalfesztivál fellépője volt, majd 1995-ben részt vett az akkor Dublinban megrendezett Eurovíziós Dalfesztiválon. Új név a régi ház falán című dalára (zeneszerző: Balázs Fecó, szövegíró: Horváth Attila) három pontot kapott, így 22. helyezést ért el. 1997-ben alapította a Feelgood Family együttest. 2000-ben közreműködött a Popsztárok című produkcióban. 2004 és 2008 között a Hálózat TV-n futott a Kincses Sziget című könnyűzenei műsora. Szigeti Csaba főként saját szerzeményeit adja elő, és felvételeit is saját stúdiójában készíti, amely 2002 óta működik.', 1995, 'Írország', 'Új név egy régi ház falán', 22, 3, NULL, NULL),
('Delhusa Gjon', NULL, 'Albán származású magyar énekes, zeneszerző és dalszövegíró. Könnyűzenei karrierjét egész fiatalon kezdte. Mindössze 18 éves volt, amikor 1971-ben a Táncdalfesztiválon előadta Kőszeghy Attila szövegíró és Kőszeghy Károly zeneszerző „Hegyek lánya” című dalát, amellyel egy csapásra ismert lett. Több neves külföldi előadó is felkérte, hogy szerezzen számukra zenét. 1980-ig részt vett valamennyi jelentős kelet-európai fesztiválon, amelyekről díjakkal tért haza. Több magyar előadónak is írt dalt, többek között Csepregi Évának és Szűcs Judithnak. 1996-ban Delhusa Gjon az Eurovíziós Dalfesztivál előválogatóján végzett a finn előadóval az utolsó, még továbbjutó helyen, ám végül utóbbi jutott tovább. Ugyanebben az évben a Mediterrán című nagylemezéért átvette Albánia legmagasabb kulturális kormánykitüntetését.', 1996, 'Norvégia', 'Fortuna', NULL, NULL, NULL, NULL),
('V.I.P.', NULL, 'Magyar könnyűzenei fiúegyüttes. Az együttes 1997-ben alakult, Budapesten, tagjai: Józsa Alex, Rácz Gergő, Rakonczai Imre, Rakonczai Viktor. 1997. május 3-án ők képviselték hazánkat az Eurovíziós dalfesztivál dublini döntőjén. 1997-ben megjelent első albumuk V.I.P címmel. Négy nagylemez után 2001 márciusában jelentették be, hogy feloszlanak és kiadták válogatás lemezüket Best of címmel. 2001. április 13-án egy koncerttel búcsúztak rajongóiktól a Kortárs Építészeti Központ (KÉK)-ben. Az együttes feloszlása után a tagok szólókarrierbe kezdtek.', 1997, 'Írország', 'Miért kell, hogy elmenj?', 12, 39, NULL, NULL),
('Charlie', 'Horváth Károly', 'Liszt Ferenc-díjas magyar énekes, könnyűzenész, a rock, a jazz, a blues, a soul és a funk jellegzetesen rekedt hangú előadóművésze, trombitás. Charlie egy időre külföldön próbált szerencsét. A 70-es évek első felében kezdett együtt dolgozni öccsével, a szaxofonon és fuvolán játszó Horváth Csabával, valamint Tátrai Tiborral, szólókarrierje 1994-ben indult. Ő képviselte Magyarországot az 1998-as Eurovíziós Dalversenyen.', 1998, 'Nagy-Britannia', 'A holnap már nem lesz szomorú', 23, 4, NULL, NULL),
('NOX', NULL, 'A NOX egy 2002 és 2009 között működött magyar zenei együttes volt, mely a magyar népzenét modern elemekkel ötvözte, frontembere Péter Szabó Szilvia volt, s nyolc albumot jelentetett meg. A 2008-as arculatváltás után 2009-ben újra a hagyományos stílusukkal jelentkeztek. A formációnak végig tagja volt Nagy Tamás is, aki végül ősszel búcsúzott a csapattól, hogy több időt szentelhessen családjának. A NOX szó a görög NÜX-ből ered, latinul éjszakát jelent, a római mitológiában Nox volt az éjszaka istennője, róla kapta a nevét az együttes. A Kijevben megrendezett 2005-ös Eurovíziós Dalfesztiválon a NOX képviselte Magyarországot.', 2005, 'Ukrajna', 'Forogj, világ!', 12, 97, 5, 167),
('Rúzsa Magdi', NULL, 'Énekesnő, dalszövegíró, dalszerző. Magdi kisgyerekkorától fogva énekel. Első igazán meghatározó zenei sikerét 2004-ben szerezte: a zentai Farsangi Ki mit tud-on megnyerte a könnyűzenei kategóriát. A TV2 Megasztár című tehetségkutató műsorának harmadik győzteseként vált ismertté. A 2007-es évet végigkoncertezte és sikerrel ő képviselte Magyarországot az Eurovíziós Dalfesztiválon. A koncertsorozat kiemelkedő eseménye volt a június 30-án megrendezett Kapcsolat koncert. 2013 februárjától A Dal című eurovíziós dalválasztó műsornak az egyik zsűritagja lett. 2018. március 13-án, a nemzeti ünnep alkalmával adták át először a Máté Péter-díjat, amely egy könnyűzenészeknek járó állami kitüntetés, a díjazottak között volt Rúzsa Magdolna is.', 2007, 'Finnország', 'Aprócska blues', 9, 128, 2, 224),
('Csézy', 'Csézi Erzsébet', 'Énekesnő. Miskolcon szerzett diplomát énekművészként és kamaraművészként 2006-ban. Konzervatóriumi pályatársaival világversenyt nyert Spanyolországban, ahol polifon és helyi baszk folklórdalokkal kápráztatta el a közönséget. Az énekesnőnek viszont más tervei voltak, a popszakmában kívánt érvényesülni. 2008. február 8-án Szívverés című dalával megnyerte  a jogot, hogy képviselhesse Magyarországot a belgrádi Eurovíziós versenyen. A 2008-as VIVA Comet díjátadón elnyerte a legjobb női előadónak járó díjat.', 2008, 'Szerbia', 'Gyertyaláng', NULL, NULL, 19, 6),
('Ádok Zoli', 'Ádok Zoltán ', 'Énekes, színész. 2007-ben jelentkezett az RTL Klub tehetségkutató műsorába a Csillag Születikbe, ahol csak a középdöntőig jutott el. A csatorna segítségével 2008-ban elkészült első szólóalbuma. Az album első kislemeze a címadó dalból készült, melyet gyakran játszottak a magyar rádiók és a zenei csatornák. 2009-ben Márk és Tompos Kátya visszalépése után őt kérték fel, hogy képviselje Magyarországot a Eurovíziós Dalfesztiválon. Még ebben az évben megjelent második kislemeze és videóklipje is. ', 2009, 'Oroszország', 'Táncolj velem', NULL, NULL, 15, 16),
('Wolf Kati', 'Wolf Katalin', 'Énekesnő. 2011-ben az év női előadója, 2012-ben A Dal zsűritagja volt. Sok slágerdal köthető. Bár gyakorlott előadó, egy nagylemezzel a háta mögött (Wolf-áramlat, 2009), valójában a magyarországi X-Faktor tehetségkutató műsorban tűnt fel 2010-ben. Ő képviselte Magyarországot a 2011-es Eurovíziós Dalfesztiválon, Düsseldorfban. 2019-ben a MAHASZ összesítése alapján a Szerelem, miért múlsz? című dala az évtized dala lett.', 2011, 'Németország', 'Mi van az álmaimmal?', 22, 53, 7, 72),
('Compact Disco', NULL, 'Elektronikus zenei együttes és zenei produceri trió. 2008-ban alapította három különböző zenei hátterű zenész Budapesten. Az együttes 2010 januárjától kezdett koncertezni, ebben az évben a nyári fesztiválidényben a zenekar szinte az összes jelentősebb magyar fesztiválon fellépett. Magyarországot ők képviselték a 2012-es Eurovíziós Dalfesztiválon Azerbajdzsánban.', 2012, 'Azerbajdzsán', 'Szíveink dallama', 24, 19, 10, 52),
('ByeAlex', 'Márta Alex', 'Énekes. Viszonylag fiatalon kezdett foglalkozni a zenével, de ezt kezdetben saját kedvtelésből, elsősorban a húga és szülei szórakoztatására tette. Például PC játékok hangjait vágta össze és készített vicces remixeket. Egyetemistaként amatőr zenekarokban kezdett komolyabban a zenével foglalkozni. Bár korábban már több kislemeze megjelent, valójában az Eurovíziós Dalfesztivál 2013-as magyar nemzeti válogatójában, A Dalban tett szert ismertségre, és ő képviselte Magyarországot a 2013-as Eurovíziós Dalfesztiválon. Ugyanebben az évben elnyerte az Év felfedezettje címet.', 2013, 'Svédország', 'Kedvesem', 10, 84, 8, 66),
('Kállay-Saunders András', NULL, 'Kállay-Saunders András amerikai–magyar énekes, előadó, producer és zeneszerző, a 2010-es Megasztár 5 negyedik helyezettje. A tehetségkutató után 2011 nyarán megjelent első kislemeze. 2014-ben megnyerte az A Dal nemzeti válogatót és ő képviselhette Magyarországot az 59. Eurovíziós Dalfesztiválon Dánia fővárosában, Koppenhágában. A verseny történetében Magyarország második legjobb eredményét érte el, továbbá a 143 ponteredménye a legtöbb, amit valaha magyar induló kapott.', 2014, 'Dánia', 'Rohanás', 5, 143, 3, 127),
('Boggie', 'Csemer Boglárka', 'Énekesnő. Zenei tanulmányait 13 éves korában kezdte. 2012-ben kezdett el dolgozni első lemezén, az addigra kiforrott stílusa igényelte a névváltoztatást, ezért a Boggie művésznevet kezdte használni. A 2013-as év végén Parfüm című dalának videóklipje által vált világszerte ismertté. ső lemeze előkelő helyen szerepelt az amerikai Billboard lista 4. majd 17. helyén. Kevés magyar előadó szerepelt eddig ezen a híres listán. A 2015-ös Eurovíziós Dalfesztiválon Bécsben Ő képviselte Magyarországot. 2018 márciusában beválasztották a világ legjelentősebb zenei Showcase fesztiváljára az amerikai Austinba.', 2015, 'Ausztria', 'Háborúk a semmiért', 20, 19, 8, 67),
('Freddie', 'Fehérvári Gábor Alfréd', 'Énekes, előadó. Már 2010-ben zenélt és voltak kisebb fellépései egyik barátjával, akinek a zenekarában rendszerint nemcsak énekelt, hanem gitározott is. Először a TV2-n futó tehetségkutató műsorban, a Rising Starban tűnt fel. A 2016-ban megrendezett 61. Eurovíziós Dalfesztiválon Freddie képviselte magyarországot. Napjainkban előadóművészként és műsorvezetőként tevékenykedik.', 2016, 'Svédország', 'Úttörő', 19, 108, 4, 197),
('Pápai Joci', 'Pápai József', 'Énekes, előadó. A nagyközönség előtt először 2005-ben mutatkozott be a TV2 Megasztár című tehetségkutató műsorának második évadában. A tehetségkutató után önálló nagylemezzel debütált. 2017-ben és 2019-ben ő képviselte Magyarországot az Eurovíziós Dalfesztiválon. Jelenleg ő az utolsó előadó, aki Magyarország színeiben fellépett a dalfesztiválon, mivel Magyarország 2020-tól nem vesz részt a versenyben.', 2017, 'Ukrajna', 'Eredet', 8, 200, 2, 231),
('AWS', NULL, 'Modern-Metal zenekar, amit 2006 nyarán alapított Brucker Bence, Kökényes Dániel, Siklósi Örs és Veress Áron, mikor egy középiskolába jártak. Eddig három nagylemezt adtak ki, játszottak már valamennyi hazai klubban és fesztiválon, illetve külföldön Romániában, Szlovéniában, Ausztriában Németországban és az Egyesült Királyságban is. Zenei hatásaik között a Metallica, Korn, System of a Down, Linkin Park, Superbutt, Subscribe és az Isten Háta Mögött zenekarokat említik. 2018-ban részt vettek A Dal című eurovíziós nemzeti dalválasztó műsorában, amit megnyertek, így ők képviselték Magyarországot a lisszaboni Eurovíziós Dalfesztiválon.', 2018, 'Portugália', 'Viszlát nyár', 21, 93, 10, 111),
('Pápai Joci', 'Pápai József', 'Énekes, előadó. A nagyközönség előtt először 2005-ben mutatkozott be a TV2 Megasztár című tehetségkutató műsorának második évadában. A tehetségkutató után önálló nagylemezzel debütált. 2017-ben és 2019-ben ő képviselte Magyarországot az Eurovíziós Dalfesztiválon. Jelenleg ő az utolsó előadó, aki Magyarország színeiben fellépett a dalfesztiválon, mivel Magyarország 2020-tól nem vesz részt a versenyben.', 2019, 'Izrael', 'Az én apám', NULL, NULL, 12, 97);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `dal`
--
ALTER TABLE `dal`
  ADD PRIMARY KEY (`ev`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
