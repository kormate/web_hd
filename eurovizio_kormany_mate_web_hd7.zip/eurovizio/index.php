<?php 



		
		$myUrl="http://localhost/eurovizio/";
		$apiUrl=$myUrl."api/"; 

		
		include_once("front/functions.php");
		
		
		include_once("front/load.php");

?>