<?php 
	//$kepek = scandir(ELOADOK);
	//unset($kepek[0], $kepek[1]);


?>


<div class="page">
<p class="center">
	
	<table class="center">
		<tr><th>Dalfesztivál éve</th><th>Rendező ország</th><th></th><th>Előadó</th></tr>
		<?php
			foreach ($mind as $rekord){
				echo "<tr>";
				echo "<td>$rekord[ev]</td>";
				echo "<td>$rekord[orszag]</td>";
				$kepek = './api/img/' . $rekord['ev'] . '.jpg';
				echo "<td><img src='$kepek' style='max-height: 180px;'></td>";
				echo "<td>$rekord[eloado]</td>";
				echo "</tr>";
				
			}
		?>
	</table>
</p>
</div>