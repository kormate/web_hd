<?php 
    $mind = getApi($apiUrl."?resztvevo=mind");
    if (!$mind) $mind=[]; 

?>



    <div class='page'>
        <?php include_once("tabla.php"); ?>
    </div>